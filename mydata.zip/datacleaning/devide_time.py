import pandas as pd


def divide_time(file_in, start, end):
    df = pd.DataFrame(pd.read_csv(file_in))
    df['time'] = pd.to_datetime(df['time'])  # 类型转换
    df.set_index('time', inplace=True)  # 设置time字段为索引
    df = df.between_time(start, end)  # 判断时间段
    a_short = start[0:5]  # 获取时间字符串
    a_replace = a_short.replace(':', '-')  # 替换字符串
    b_short = end[0:5]
    b_replace = b_short.replace(':', '-')
    # filenamea = file_in[0:7]  # 获取部分文件输出路径
    # filenameb = file_in[20:26]
    df.to_csv('time ' + a_replace + '~' + b_replace + '.csv', index=False)
    print(df)


if __name__ == '__main__':
    time_ = [["00:00:00", "01:00:00"],
             ["01:00:00", "02:00:00"],
             ["02:00:00", "03:00:00"],
             ["03:00:00", "04:00:00"],
             ["04:00:00", "05:00:00"],
             ["05:00:00", "06:00:00"],
             ["06:00:00", "07:00:00"],
             ["07:00:00", "08:00:00"],
             ["08:00:00", "09:00:00"],
             ["09:00:00", "10:00:00"],
             ["10:00:00", "11:00:00"],
             ["11:00:00", "12:00:00"],
             ["12:00:00", "13:00:00"],
             ["13:00:00", "14:00:00"],
             ["14:00:00", "15:00:00"],
             ["15:00:00", "16:00:00"],
             ["16:00:00", "17:00:00"],
             ["17:00:00", "18:00:00"],
             ["18:00:00", "19:00:00"],
             ["19:00:00", "20:00:00"],
             ["20:00:00", "21:00:00"],
             ["21:00:00", "22:00:00"],
             ["22:00:00", "23:00:00"],
             ["23:00:00", "00:00:00"]]
    file_in = '../output/shenzhen_taxi_gps.csv'
    for i in range(0, 24):  # 遍历时间段
        divide_time(file_in, time_[i][0], time_[i][1])
