import pandas as pd
import time
import sys

DEFAULT_LAT_MIN = 22.27
DEFAULT_LAT_MAX = 22.86
DEFAULT_LON_MIN = 113.75
DEFAULT_LON_MAX = 114.37


# 数据清洗
def data_cleaning(file_in_path, file_out_path, lat_min=DEFAULT_LAT_MIN, lat_max=DEFAULT_LAT_MAX,
                  lon_min=DEFAULT_LON_MIN, lon_max=DEFAULT_LON_MAX):
    reader = pd.read_csv(file_in_path, chunksize=1000000)
    for index, df in enumerate(reader):
        df = df.dropna()  # 处理空值
        df = df.drop_duplicates()  # 删除重复值
        df = df[(df.latitude >= lat_min) & (df.latitude <= lat_max)]  # 处理纬度
        df = df[(df.longitude >= lon_min) & (df.longitude <= lon_max)]  # 处理经度
        df = df[(df.state == 3)]  # 去掉所有空车状态的数据
        df = df[(df.speed == 0)]  # 处理速度
        if index == 0:  # 检查是否是第一次写入数据,决定是否写入header
            df.to_csv(file_out_path, mode="a", index=False)  # 追加写入新的csv文件
        else:
            df.to_csv(file_out_path, mode="a", index=False, header=0)  # 追加写入新的csv文件


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: python script_name.py input_file_path output_file_path [lat_min] [lat_max] [lon_min] [lon_max]")
    else:
        start = time.time()
        filein = sys.argv[1]
        fileout = sys.argv[2]
        if len(sys.argv) == 7:
            lat_min = float(sys.argv[3])
            lat_max = float(sys.argv[4])
            lon_min = float(sys.argv[5])
            lon_max = float(sys.argv[6])
            data_cleaning(filein, fileout, lat_min, lat_max, lon_min, lon_max)
        else:
            data_cleaning(filein, fileout)
        end = time.time()
        print("Runtime: " + str(end - start))
